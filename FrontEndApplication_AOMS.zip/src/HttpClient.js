import axios from 'axios';

const httpClient = axios.create({
   
});

export {httpClient}