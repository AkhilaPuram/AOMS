import React from "react";
import "./Modal.css";

const Modal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-order">
      <div className="modal-content-order">
        <span className="close" onClick={onClose}>
          &times;
        </span>
        <p>Your order is successful!</p>
      </div>
    </div>
  );
};

export default Modal;
