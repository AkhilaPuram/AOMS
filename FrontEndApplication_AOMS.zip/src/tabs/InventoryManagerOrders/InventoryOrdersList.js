import React, { useEffect, useState } from "react";
import InventoryOrders from "./InventoryOrders";
import axios from "axios";
import { blueGrey } from "@mui/material/colors";
import OrdersList from "../OrdersList/OrdersList";
import "../OrdersList/OrdersList.css";
import UserInfo from "../../components/UserInfo";
import {Checkbox, dividerClasses} from"@mui/material"
import { useAsyncError, useNavigate } from "react-router-dom";
const InventoryOrdersList = () => {
  const [noApproval, setNoApproval] = useState(true);
  const [Order, setOrder] = useState([]);
  const [orderItem, setorderItem] = useState([]);
  const [checked, setChecked] = useState(false);
  const [comments, setComments] = useState("");
  const [TaskID, setTaskID] = useState(0);
  // const[first,setFirst]=useState(0);
  // const[last,setLast]=useState(5);
  // const [val,setVal]=useState(true)
  // const navigate=useNavigate();
  useEffect(() => {
    fetchOrderData();
  }, []);

  const userEmail = localStorage.getItem("email");
  let userGroups = localStorage.getItem("groups");
  console.log("----usergroup---"+userGroups);
  
  //Data from API for date and orderID
  
  const fetchOrderData = async () => {
    userGroups = userGroups.replace(/['"]+/g, '')
    const baseURL1 = `http://localhost:8899/api/tasklist/GetAllOpenOrders/${userGroups}`;
    try {
      
      const orderData = await axios.get(baseURL1).then((res) => res.data);

      setOrder([...orderData]);
    } catch (err) {
      console.log(err);
    }
  };
console.log(orderItem);
  const moveToApproval = async (id) => {
    setTaskID(id);
    setNoApproval(false);
    const baseURL = `http://localhost:8899/api/tasklist/${id}/gettaskinfo`;
    try {
      let planDetails = await axios.get(baseURL).then((res) => res.data);
      let dataItem = planDetails.orderitem;
      let newItem = dataItem.map(function (item) {
        return { ...item, taskId: id };
      });

      setorderItem([...newItem]);
    } catch (err) {
      console.log(err);
    }
  };

  //   const variables = {
  //     variables: [
  //       { name: "isApprove", value: '"true"' },
  //       { name: "ApproverComments", value: '"approved"' },
  //       { name: "hasBroadbandService", value: '"true"' },
  //     ],
  //   };
  const Submit = async () => {
   
    
    const variables = {
      "variables": [{ "name": "isResourceAvailable", "value": "\""+`${checked}`+ "\"" }
      ]

    }
    try {
      const result = await axios
        .patch(
          `http://localhost:8899/api/tasklist/CompleteTask/${TaskID}`,
          variables
        )
        .then((res) => {
          console.log(res.data);
        });
    } catch (err) {
      console.log(err.message);
    }
   
  };


  return (
    <div className="orders-list">
      {Order.length === 0 ? (
        <div className="no-orders-message">No orders to show on the page.</div>
      ) : noApproval ? <div>
        {
        Order.map((order) => (
          <div key={order.id} className="order-card">
            <div className="order-header">
              <div>
                <strong>Order ID - </strong> {order.id}
              </div>
              <div>
                <strong>Date - </strong> {order.creationDate.substring(0,10)}
              </div>
              {/* <div>
                <strong>Status - </strong> <span>To Be Checked</span>
              </div> */}
              <button
                style={{ width: "80px" }}
                onClick={() => moveToApproval(order.id)}
              >
                Details
              </button>
            </div>
           
          </div>
        ))
               }   
        </div> : (
      
        <div>
          { orderItem.length>0 &&<UserInfo userDetails={[...orderItem]}/>}
          
          <div className="order-details">
            <div style={{display:"flex",flexDirection:"column"}}>
            
            <div>
            <h3 style={{paddingLeft:"4px"}}>List of Plans</h3>
              {orderItem.map((plan, index) => (<div style={{display:"flex"}}>
                <div key={index} className="listItems">
                  <div><strong>Plan ID</strong> <span>{plan.id}</span></div><div> <strong>Amount</strong>
                    <span> {plan.order.priceAmount}</span></div>
                  <div><strong>Quantity</strong><span>{plan.quantity}</span></div>
                  <div><strong>Data</strong> <span>UNLIMITED</span></div>
                  <div><strong>Validity</strong>
                    <span>BillCycle</span></div>

                </div>
                </div>
              ))}
              <div>
              <label for="comments" style={{ paddingTop: "10px" }}>Comments:</label>
              <textarea id="comments"
                name="comments"
                value={comments}
                rows="3"
                cols="35"
                onChange={(e) => setComments(e.target.value)}
                style={{ border: "whitesmoke solid 3px", borderRadius: "5px" }}></textarea>
                </div>
               
              
              <div style={{margin:"10px",marginLeft:"0px"}}>
              <Checkbox type="checkbox"sx={{marginRight:"3px",padding:"0px"}}  name="Resources" onChange={() => { setChecked(!checked) }}/>Resource Required
             </div>
            </div>
           </div>
          </div>
          <a href="/inventoryManager-orders"><button style={{ width: "80px" }} onClick={() => Submit()}>
            Submit
          </button></a>
        </div>
      )}
    </div>

  )

}
export default InventoryOrdersList;
