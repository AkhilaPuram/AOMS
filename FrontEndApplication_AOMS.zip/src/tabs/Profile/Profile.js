// Profile.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import './Profile.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';

function Profile() {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate(); 

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const handleLogout = () => {
        // Perform logout actions if needed
        // For example, clearing session, etc.
        // Then redirect to the login page
        navigate('/'); // Redirect to the login page
    };

    const handleMyProfile = () => {
        // Redirect to the profile page
        navigate('/profile');
    };
    return (
        <div className="customer-home-container">
        <aside className="sidebar">
        <nav>
                        <ul>
                        <li><a href="/customer-home">Home</a></li>
                    <li><a href="/orders">Orders</a></li>
                    <li><a href="/bills">Bills</a></li>
                        </ul>
                    </nav>
        </aside>
        <main className="main-content">
            <header>
            <div className="profile-icon profile-icon-container" onClick={toggleDropdown}>
                <FontAwesomeIcon icon={faUser} />
                {isDropdownOpen && (
                        <div className="dropdown">
                            <ul>
                                <li><a href="#" onClick={handleMyProfile}>My Profile</a></li>
                                <li><a href="#" onClick={handleLogout}>Logout</a></li>
                            </ul>
                        </div>
                    )}
                 </div>
            </header>
            <section className="content">
            <div className="profile-container">
            <h2>My Profile</h2>

            <div className="profile-content">
                {/* Personal Details */}
                <div className="profile-card">
                    <h3>Personal Details</h3>
                    <ul>
                        <li><strong>Name:</strong> John Doe</li>
                        <li><strong>Email:</strong> johndoe@example.com</li>
                        <li><strong>Phone:</strong> +1234567890</li>
                        <li><strong>Address:</strong> 123 Main St, City, Country</li>
                    </ul>
                </div>

                {/* Bill Preferences */}
                <div className="profile-card">
                    <h3>Bill Preferences</h3>
                    <ul>
                        <li><strong>Notification Preferences:</strong> Email</li>
                        <li><strong>Payment Method:</strong> Credit Card</li>
                    </ul>
                </div>
            </div>

            {/* Change Password */}
            <div className="profile-card">
                <h3>Change Password</h3>
                <form>
                    <div className="form-group">
                        <label htmlFor="currentPassword">Current Password:</label>
                        <input type="password" id="currentPassword" name="currentPassword" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="newPassword">New Password:</label>
                        <input type="password" id="newPassword" name="newPassword" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="confirmPassword">Confirm Password:</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" />
                    </div>
                    <button type="submit">Change Password</button>
                </form>
            </div>
        </div>
            </section>
        </main>
    </div>
    );
}

export default Profile;
