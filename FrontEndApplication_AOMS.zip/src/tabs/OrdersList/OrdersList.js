// OrdersList.js
import React, { useState, useEffect } from "react";
import "./OrdersList.css"; // Import CSS for OrdersList component
import axios from "axios";
import {Radio} from "@mui/material";
import UserInfo from "../../components/UserInfo";
import { useNavigate } from "react-router-dom";
// import { useNavigate } from 'react-router-dom';

function OrdersList() {
  //const [expandedOrder, setExpandedOrder] = useState(null);

  // Function to handle expanding/collapsing order details
  // const toggleOrderDetails = (orderId) => {
  //     setExpandedOrder(expandedOrder === orderId ? null : orderId);
  // };
  const [noApproval, setNoApproval] = useState(true);
  const [Order, setOrder] = useState([]);
  const [orderItem, setorderItem] = useState([]);
  const [approved, setApproved] = useState("");
  // const [Rejected, setReject] = useState(false);
  const [comments, setComments] = useState("");
  const [TaskID, setTaskID] = useState(0);
  const[group,setGroup]=useState();
  const navigate=useNavigate()
  useEffect(() => {
    fetchOrderData();
  }, []);

  //Data from API for date and orderID
  const userEmail = localStorage.getItem("email");
  let userGroups = localStorage.getItem("groups");
  console.log("----usergroup---"+userGroups);
  
  const fetchOrderData = async () => {
    
    try {

      userGroups = userGroups.replace(/['"]+/g, '')
      const baseURL1 = `http://localhost:8899/api/tasklist/GetAllOpenOrders/${userGroups}`;
      console.log(baseURL1);
      const orderData = await axios.get(baseURL1).then((res) => res.data);

      setOrder([...orderData]);
    } catch (err) {
      console.log(err.message);
    }
  };
  

  const moveToApproval = async (id) => {
    setTaskID(id);
    setNoApproval(false);
    const baseURL = `http://localhost:8899/api/tasklist/${id}/gettaskinfo`;
    try {
      let planDetails = await axios.get(baseURL).then((res) => res.data);
      let dataItem = planDetails.orderitem;
      let newItem = dataItem.map(function (item) {
        return { ...item, taskId: id };
      });

      setorderItem([...newItem]);
    } catch (err) {
      console.log(err);
    }
  };

  //   const variables = {
  //     variables: [
  //       { name: "isApprove", value: '"true"' },
  //       { name: "ApproverComments", value: '"approved"' },
  //       { name: "hasBroadbandService", value: '"true"' },
  //     ],
  //   };
  const Submit = async (id) => {
    const variables = {
      variables: [
        { name: "isApprove", value: "\""+`${approved}`+ "\"" },
        { name: "ApproverComments", value: "\""+`${comments}`+ "\"" },
        { name: "hasBroadbandService", value: '\"true\"' },
      ],
    };
    try {
      const result = await axios
        .patch(
          `http://localhost:8899/api/tasklist/CompleteTask/${TaskID}`,
          variables
        )
        .then((res) => {
          console.log(res.data);
        });
    } catch (err) {
      console.log(err.message);
    }
    alert("Data submitted successfully");
   
    
  };

  // const changeToApprove = () => {
  //   setApproved(!approved);
  // };
  return (
    <div className="orders-list">
      {Order.length === 0 ? (
        <div className="no-orders-message">No orders to show on the page.</div>
      ) : noApproval ? (
        Order.map((order) => (
          <div key={order.id} className="order-card">
            <div className="order-header">
              <div>
                <strong>Order ID -</strong> {order.id}
              </div>
              <div>
                <strong>Date - </strong> {order.creationDate.substring(0,10)}
              </div>
              {/* <div>
                <strong>Status - </strong> <span>To Be Checked</span>
              </div> */}
              <button
                style={{ width: "80px" }}
                onClick={() => moveToApproval(order.id)}
              >
                Details
              </button>
            </div>
          </div>
        ))
      ) : (
        <div>
          { orderItem.length>0 &&<UserInfo userDetails={[...orderItem]}/>}
          <div className="order-details">
           
            <div>
            <h3 style={{paddingLeft:"4px"}}>List of Plans</h3>
              {orderItem.map((plan, index) => (<div style={{display:"flex"}}>
             
                <div key={index} className="listItems">
                  <div><strong>Plan ID</strong> <span>{plan.id}</span></div><div> <strong>Amount</strong>
                    <span> {plan.order.priceAmount}</span></div>
                  <div><strong>Quantity</strong><span>{plan.quantity}</span></div>
                  <div><strong>Data</strong> <span>UNLIMITED</span></div>
                  <div><strong>Validity</strong>
                    <span>BillCycle</span></div>
 
                </div>
               
               </div>
              ))}
              <div>
              <label for="comments" style={{paddingTop:"8px"}}>Comments:</label>
              <textarea id="comments"
                name="comments"
                value={comments}
                rows="3"
                cols="35"
                onChange={(e) => setComments(e.target.value)}
               style={{border:"whitesmoke solid 3px",borderRadius:"5px"}}></textarea></div>
              <div className="radioBtn">
                <div className="radio_label">
              <input className ="input_label" type="radio" name="Approval" value= "Approve"
                
                onChange={(e) => setApproved(true)}
              /><span style={{ padding: "2px", margin: "1px",verticalAlign:"baseline" }}><strong>Approve</strong></span>
              </div>
              <div className="radio_label" >
              <input  className ="input_label"type="radio"  name="Approval" value ="Reject"
                
                onChange ={(e) =>
                  setApproved(false)
                }
              /><span style={{ padding: "2px", margin: "1px" }}><strong>Reject</strong></span>
              </div>
              </div>
            </div>
          </div>
          <a href="/admin-orders"><button style={{ width: "100px"}} onClick={() => Submit()}>
            Submit
          </button></a>
        </div>
      )}
    </div>
  );
}
 
export default OrdersList;