// Bills.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import './Bills.css'; // Import CSS for Bills component
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';

function Bills() {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate(); 

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const handleLogout = () => {
        // Perform logout actions if needed
        // For example, clearing session, etc.
        // Then redirect to the login page
        navigate('/'); // Redirect to the login page
    };

    const handleMyProfile = () => {
        // Redirect to the profile page
        navigate('/profile');
    };
    // Mock data for payments
    const payments = [
        { id: 1, phoneNumber: '1234567890', validity: '2022-01-01', amount: 20, status: 'Paid' },
        { id: 2, phoneNumber: '9876543210', validity: '2022-02-01', amount: 30, status: 'Pending' },
        { id: 3, phoneNumber: '8765432109', validity: '2022-03-01', amount: 25, status: 'Paid' },
        // Add more payment data as needed
    ];

    return ( <div className="customer-home-container">
    <aside className="sidebar">
    <nav>
                    <ul>
                    <li><a href="/customer-home">Home</a></li>
                <li><a href="/orders">Orders</a></li>
                <li><a href="/bills">Bills</a></li>
                    </ul>
                </nav>
    </aside>
    <main className="main-content">
        <header>
        <div className="profile-icon profile-icon-container" onClick={toggleDropdown}>
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
                    <div className="dropdown">
                        <ul>
                            <li><a href="#" onClick={handleMyProfile}>My Profile</a></li>
                            <li><a href="#" onClick={handleLogout}>Logout</a></li>
                        </ul>
                    </div>
                )}
             </div>
        </header>
        <section className="content">
        <div className="bills-container">
            <h2>All Payments</h2>
            {payments.map(payment => (
                <div key={payment.id} className="bill">
                    <div className="bill-field">
                        <span className="label">Prepaid:</span>
                        <span className="value">{payment.phoneNumber}</span>
                    </div>
                    <div className="bill-field">
                        <span className="label">Validity:</span>
                        <span className="value">{payment.validity}</span>
                    </div>
                    <div className="bill-field">
                        <span className="label">Amount:</span>
                        <span className="value">${payment.amount}</span>
                    </div>
                    <div className="bill-field">
                        <span className="label">Status:</span>
                        <span className="value">{payment.status}</span>
                    </div>
                </div>
            ))}
        </div>
        </section>
    </main>
</div>
        
    );
}

export default Bills;
