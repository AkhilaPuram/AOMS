import React from 'react';
import './Payment.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronDown } from '@fortawesome/free-solid-svg-icons';

function PaymentPage() {
    return (
        <div className="customer-home-container">
         <main className="main-content">
         <header>
            </header>
            <section>
        <div className="payment-page">
        <div className="payment-options">
                    <h2>Payment Options</h2>
                    <div className="payment-option-card">
                        <p>Credit Cards</p>
                        <FontAwesomeIcon icon={faChevronDown} />
                    </div>
                    <div className="payment-option-card">
                        <p>Netbanking</p>
                        <FontAwesomeIcon icon={faChevronDown} />
                    </div>
                    <div className="payment-option-card">
                        <p>UPI</p>
                        <FontAwesomeIcon icon={faChevronDown} />
                    </div>
                    <div className="payment-option-card">
                        <p>Wallets</p>
                        <FontAwesomeIcon icon={faChevronDown} />
                    </div>
                </div>
                <div className="payment-summary">
                    <h2>Payment Summary</h2>
                    <div className="payment-details-card">
                    <div className="plan-details">
                        <p>Amount: $10</p>
                        <p>Data: 2GB</p>
                        <p>Validity: 30 days</p>
                    </div>
                    </div>
                    <div className="amount-payable">
                        <p>Amount Payable: $10</p>
                    </div>
                    <div>
                    <button>Pay Now</button>
                    </div>
                </div>
        </div>
        </section>
        </main>
        </div>
    );
}

export default PaymentPage;
