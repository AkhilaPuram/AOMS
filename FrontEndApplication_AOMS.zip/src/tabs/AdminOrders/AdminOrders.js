// Bills.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminOrders.css"; // Import CSS for Bills component
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import OrderList from "../OrdersList/OrdersList";

function AdminOrders() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    // Perform logout actions if needed
    // For example, clearing session, etc.
    // Then redirect to the login page
    navigate("/"); // Redirect to the login page
  };

  const handleMyProfile = () => {
    // Redirect to the profile page
    navigate("/profile");
  };
  const [filterStatus, setFilterStatus] = useState("all");

  const handleFilterChange = (event) => {
    setFilterStatus(event.target.value);
  };
  const ordersData = [
    {
      id: 1,
      orderId: "ORD123",
      date: "2024-01-30",
      status: "pending",
      plans: [
        { planId: "P001", amount: "$20", data: "5GB", validity: "30 days" },
        { planId: "P002", amount: "$30", data: "10GB", validity: "30 days" },
      ],
    },
    {
      id: 2,
      orderId: "ORD124",
      date: "2024-01-31",
      status: "approved",
      plans: [
        { planId: "P003", amount: "$40", data: "15GB", validity: "30 days" },
      ],
    },
    {
      id: 1,
      orderId: "ORD1267",
      date: "2024-01-30",
      status: "canceled",
      plans: [
        { planId: "P001", amount: "$20", data: "5GB", validity: "30 days" },
        { planId: "P002", amount: "$30", data: "10GB", validity: "30 days" },
      ],
    },
    {
      id: 1,
      orderId: "ORD1286",
      date: "2024-01-30",
      status: "pending",
      plans: [
        { planId: "P001", amount: "$20", data: "5GB", validity: "30 days" },
        { planId: "P002", amount: "$30", data: "10GB", validity: "30 days" },
      ],
    },
    // Add more orders as needed
  ];

  // Event handlers for order actions
  const handleApprove = (orderId) => {
    // Handle order approval
    console.log("Approving order:", orderId);
  };

  const handleCancel = (orderId) => {
    // Handle order cancellation
    console.log("Cancelling order:", orderId);
  };

  const handleModify = (orderId) => {
    // Handle order modification
    console.log("Modifying order:", orderId);
  };

  // Filter orders based on selected status
  const filteredOrders =
    filterStatus === "all"
      ? ordersData
      : ordersData.filter((order) => order.status === filterStatus);

  return (
    <div className="customer-home-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <a href="/admin-home">Dashboard</a>
            </li>
            <li>
              <a href="/admin-orders">Manage Orders</a>
            </li>
            <li>
              <a >Settings</a>
            </li>
            <li>
              <a >Help</a>
            </li>
            <li>
              <a>About</a>
            </li>
          
          </ul>
        </nav>
      </aside>
      <main className="main-content">
        <header>
          <div
            className="profile-icon profile-icon-container"
            onClick={toggleDropdown}
          >
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
              <div className="dropdown">
                <ul>
                  <li>
                    <a href="#" onClick={handleMyProfile}>
                      My Profile
                    </a>
                  </li>
                  <li>
                    <a href="#" onClick={handleLogout}>
                      Logout
                    </a>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </header>
        <section className="content">
          <div className="orders-page-container">
            <h2>Orders</h2>

            <OrderList orders={filteredOrders} />
          </div>
        </section>
      </main>
    </div>
  );
}

export default AdminOrders;
