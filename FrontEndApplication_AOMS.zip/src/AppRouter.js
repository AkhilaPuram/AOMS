import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./components/Login/Login";
import CustomerHome from "./components/Customer/CustomerHome";
import AdminHome from "./components/Admin/AdminHome"; // Create AdminHome component
import Profile from "./tabs/Profile/Profile";
import PaymentPage from "./tabs/Payment/Payment";
import Bills from "./tabs/Bills/Bills";
import Orders from "./tabs/Orders/Orders";
import OrderDetails from "./components/Customer/OrderDetails";
import AdminOrders from "./tabs/AdminOrders/AdminOrders";
import InventoryOrders from "./tabs/InventoryManagerOrders/InventoryOrders";
import ServiceOrders from "./tabs/ServiceEngineerOrders/ServiceOrders";
import ServiceManagerOrders from "./tabs/ServiceManagerOrders/ServiceManagerOrders";
import HomePage from "../src/components/HomePage/HomePage";
import { useLocation } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import Keycloak from "keycloak-js";
import axios from "axios";
 
function AppRouter() {
  const [handleOrder, sethandleOrder] = useState([]);
  const [kc, setKc] = useState(() => {
    const storedKc = localStorage.getItem("kc");
    return storedKc ? JSON.parse(storedKc) : null;
  });
  const handleOrderDetails = (ele) => {
    sethandleOrder((prevState) => [...prevState, { ...ele }]);
  };
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [group, setGroup] = useState("");
  const [email, setEmail] = useState("ap@gmail.com");
  //const location = useLocation();
 
  useEffect(() => {
    if (kc) {
      localStorage.setItem("kc", JSON.stringify(kc));
    } else {
      localStorage.removeItem("kc");
    }
  }, [kc]);
 
  const handleLogin = () => {
    setLoading(true);
    let initOptions = {
      url: "http://10.13.1.180:18080/auth/",
      realm: "camunda-platform",
      clientId: "react-client",
    };
 
    let keycloak = new Keycloak(initOptions);
    keycloak
      .init({
        onLoad: "login-required",
        checkLoginIframe: true,
        pkceMethod: "S256",
      })
      .then((authenticated) => {
        if (authenticated) {
          setKc(keycloak);
          console.log("Authenticated ");
          console.log(" access token" + keycloak.token);
          console.log(" access token" + keycloak.userInfo);
          const decoded = jwtDecode(keycloak.token);
          console.log("decode name " + decoded.name);
          console.log("decoded email " + decoded.email);
          console.log("decoded groups " + decoded.groups);
          localStorage.setItem("email", decoded.email);
          localStorage.setItem("groups", decoded.groups);
          const mailId = async () => {
            let result = await axios.get(
              `http://localhost:8899/user/GetGroupAttribute/${decoded.email}`
            );
            let resdata = await result.data;
            await localStorage.setItem("groups", resdata);
            if (resdata === "ServiceManagers") {
              //localStorage.setItem("groups", JSON.stringify("ServiceManagers"));
              window.location.href = "/serviceManager-orders";
            } else if (resdata === "ServiceEngineers") {
              // localStorage.setItem(
              //   "groups",
              //   JSON.stringify("ServiceEngineers")
              // );
              window.location.href = "/serviceEngineer-orders";
            } else if (resdata === "OrderApprovers") {
              window.location.href = "/admin-home";
            } else if (resdata === "ResourceManagers") {
              window.location.href = "/inventoryManager-orders";
            }
          };
          mailId();
        } else {
          console.log("Authentication failed");
        }
      })
      .catch((err) => {
        console.error("Error initializing Keycloak: ", err);
        setLoading(false);
      });
  };
 
  const handleLogout = () => {
    console.log(kc);
    // if (kc) {
    //   kc.logout();
      window.location.href = "http://localhost:3000";
    // }
  };
 
  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <>
              <HomePage handleLogin={handleLogin} handleLogout={handleLogout} />
              
            </>
          }
        />
        <Route
          path="/customer-home"
          element={
            <CustomerHome
              OrderDetails={handleOrderDetails}
              handleLogout={handleLogout}
            />
          }
        />
        <Route
          path="/admin-home"
          element={<AdminHome handleLogout={handleLogout} />}
        />
        <Route path="/admin-orders" element={<AdminOrders />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/payment" element={<PaymentPage />} />
        <Route path="/bills" element={<Bills />} />
        <Route path="/orders" element={<Orders email={email} />} />
        <Route
          path="/orderDetails"
          element={<OrderDetails orderCard={handleOrder} />}
        />
        <Route
          path="/serviceManager-orders"
          element={<ServiceManagerOrders />}
        />
        <Route path="/inventoryManager-orders" element={<InventoryOrders />} />
        <Route path="/serviceEngineer-orders" element={<ServiceOrders />} />
      </Routes>
    </Router>
  );
}
 
export default AppRouter;
 