import React, { useState, useEffect, useRef } from "react";
// import PlanDetails from "./PlanDetails";
import "./OrderCreation.css";
import axios from "axios";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Image1 from "../../Image/1.png";
import Image2 from "../../Image/2.png";
import Image3 from "../../Image/3.png";
import Image4 from "../../Image/4.png";
// import Image5 from "../../Image/Image5.jpg";
import Modal from "../../Modal/Modal";

const OrderForm = ({ handleLoginClick }) => {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [step, setStep] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    customer: {
      title: "",
      firstName: "",
      lastName: "",
      middleName: "",
      homePhone: "",
      fax: "",
      businessPhone: "",
      emailID: "",
      customrType: "",
      suffix: "",
    },
    address: [
      {
        street1: "",
        street2: "",
        city: "",
        State: "",
        country: "",
        PostalCode: "",
        // addressType: "",
      },
    ],
    order: {
      shippingAmount: "",
      priceAmount: "",
      specialInstructions: "",
      shippingMethod: "",
      ordersSubtotal: "",
    },
    orderitem: [],
  });
  const [products, setProducts] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);

  useEffect(() => {
    if (!isDataFetched) {
      const fetchData = async () => {
        try {
          const response = await axios.get(
            "http://localhost:8899/api/getproducts"
          );
          setProducts(response.data);
          setIsDataFetched(true);
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      };
      fetchData();
    }
  }, [isDataFetched]);

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setSelectedPlan(null);
    // if (scrollRef.current) {
    //   scrollRef.current.scrollIntoView({ behavior: "smooth" });
    // }
    const categoryLabels = document.querySelectorAll(".category-label");
    categoryLabels.forEach((label) => {
      if (label.textContent === category) {
        label.classList.add("selected-category");
      } else {
        label.classList.remove("selected-category");
      }
    });
  };

  // const handlePlanSelect = (plan) => {
  //   setSelectedPlan(plan);
  //   const isSelected = formData.orderitem.some((item) => item.plan === plan);
  //   if (isSelected) {
  //     setFormData((prevData) => ({
  //       ...prevData,
  //       orderitem: prevData.orderitem.filter((item) => item.plan !== plan),
  //     }));
  //   } else {
  //     setFormData((prevData) => ({
  //       ...prevData,
  //       orderitem: [{ plan: plan }],
  //     }));
  //   }
  // };

  const handlePlanSelect = (plan) => {
    setSelectedPlan(plan);
    const isSelected = formData.orderitem.some((item) => item.plan === plan);
    if (isSelected) {
      setFormData((prevData) => ({
        ...prevData,
        orderitem: prevData.orderitem.filter((item) => item.plan !== plan),
      }));
    } else {
      const orderItem = {
        plan: plan,
        serviceType: selectedCategory,
      };
      setFormData((prevData) => ({
        ...prevData,
        orderitem: [...prevData.orderitem, orderItem],
      }));
    }
  };

  // const handleSubmit = () => {
  //   const taxAmount = selectedPlan.price;
  //   const ordersSubtotal = selectedPlan.price;
  //   const description = `Validity: ${selectedPlan.validity}, Speed: ${selectedPlan.speed}`;
  //   const orderItem = {
  //     // productID: selectedPlan.productID, // Assuming the plan has an id property
  //     taxAmount: taxAmount,
  //     quantity: 1, // Assuming quantity is always 1
  //     description: description,
  //     serviceType: selectedCategory,
  //   };
  //   const addresses = [
  //     {
  //       street1: formData.address.street1,
  //       street2: formData.address.street2,
  //       city: formData.address.city,
  //       state: formData.address.State,
  //       country: formData.address.country,
  //       postalCode: formData.address.PostalCode,
  //     },
  //   ];
  //   // const priceAmount = formData.orderitem.reduce(
  //   //   (total, item) => total + parseInt(item.price),
  //   //   0
  //   // );
  //   // const { ShippingAmount, SpecialInstructions } = formData.order;
  //   const shippingAmount = 99;
  //   const priceAmount = selectedPlan.price;
  //   const finalOrder = {
  //     customer: {
  //       ...formData.customer,
  //     },
  //     address: addresses,
  //     order: {
  //       shippingAmount: shippingAmount,
  //       priceAmount: priceAmount, // Update price amount here
  //       specialInstructions: formData.order.specialInstructions,
  //       ordersSubtotal: ordersSubtotal,
  //       shippingMethod: formData.order.shippingMethod,
  //     },
  //     // formData.order,
  //     // orderitem: formData.orderitem.map((item) => item.plan),
  //     orderitem: orderItem,
  //   };

  //   console.log(finalOrder);
  //   setFormData({
  //     customer: {
  //       title: "",
  //       firstName: "",
  //       lastName: "",
  //       middleName: "",
  //       homePhone: "",
  //       fax: "",
  //       businessPhone: "",
  //       customrType: "",
  //       emailID: "",
  //     },
  //     address: [
  //       {
  //         street1: "",
  //         street2: "",
  //         city: "",
  //         state: "",
  //         country: "",
  //         PostalCode: "",
  //         // addressType: "",
  //       },
  //     ],
  //     order: {
  //       shippingAmount: "",
  //       priceAmount: "", // Update price amount here
  //       specialInstructions: "",
  //       ordersSubtotal: "",
  //       shippingMethod: "",
  //     },
  //     orderitem: [],
  //   });
  //   setSelectedPlan(null);
  //   setSelectedCategory(null);
  //   setStep(1);
  //   alert("Form submitted successfully!");
  //   setIsModalOpen(true);
  // };

  const handleSubmit = async () => {
    // if (formData.customer.emailID === "") {
    //   alert("Please fill in the email field.");
    //   return;
    // }
    // if (!validateEmail(formData.customer.emailID)) {
    //   alert("Please enter a valid email address.");
    //   return;
    // }
    const taxAmount = selectedPlan.price;
    const description = `Validity: ${selectedPlan.validity}, Speed: ${selectedPlan.speed}`;
    const orderItem = {
      // productID: selectedPlan.productID,
      taxAmount: taxAmount,
      quantity: 1, // Assuming quantity is always 1
      description: description,
      serviceType: selectedCategory,
    };
    const addresses = [
      {
        street1: formData.address.street1,
        street2: formData.address.street2,
        city: formData.address.city,
        state: formData.address.State,
        country: formData.address.country,
        postalCode: formData.address.PostalCode,
      },
    ];
    //const addresses = Object.values(formData.address).map(address => ({     ...address   }));
    const shippingAmount = 99;
    const priceAmount = selectedPlan.price;
    const ordersSubtotal = selectedPlan.price;
    const finalOrder = {
      customer: formData.customer,
      address: addresses,
      order: {
        shippingAmount: shippingAmount,
        priceAmount: priceAmount, // Update price amount here
        specialInstructions: formData.order.specialInstructions,
        ordersSubtotal: ordersSubtotal,
        shippingMethod: formData.order.shippingMethod,
      },
      orderitem: [orderItem],
    };
    console.log(finalOrder);

    try {
      const response = await axios.post(
        "http://localhost:8899/api/etom/createorder",
        finalOrder
      );
      console.log(response.data);
      setFormData({
        customer: {
          title: "",
          firstName: "",
          lastName: "",
          middleName: "",
          homePhone: "",
          fax: "",
          businessPhone: "",
          emailID: "",
          customrType: "",
          suffix: "",
        },
        address: [
          {
            street1: "",
            street2: "",
            city: "",
            state: "",
            country: "",
            PostalCode: "",
            // addressType: "",
          },
        ],
        order: {
          shippingAmount: "",
          priceAmount: "",
          specialInstructions: "",
          ordersSubtotal: "",
          shippingMethod: "",
        },
        orderitem: [],
      });
      setSelectedPlan(null);
      setSelectedCategory(null);
      // setIsModalOpen(true);
      setStep(1);
      // setStep(step + 1);
      alert("Order submitted successfully !!");
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    resetForm();
  };

  const handleNext = () => {
    if (step === 2) {
      // Check if any customer information field is empty
      const { title, firstName, lastName, emailID } = formData.customer;
      if (!title || !firstName || !lastName || !emailID) {
        alert("Please fill all customer information fields.");
        return;
      }
      if (!validateEmail(emailID)) {
        alert("Please enter a valid email address.");
        return;
      }
    }

    if (step === 3) {
      const { street1, city, State, country, PostalCode } = formData.address;
      if (!street1 || !city || !State || !country) {
        alert("Please fill all address fields.");
        return;
      }
    }

    setStep(step + 1);
  };
  const validateEmail = (email) => {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  };
  const handleBack = () => {
    setStep(step - 1);
  };

  //Function to handle form data change
  const handleChange = (e, section) => {
    const { name, value } = e.target;
    const numericFields = ["homePhone", "fax", "businessPhone"];
    if (numericFields.includes(name)) {
      if (value === "" || /^\d+$/.test(value)) {
        setFormData((prevData) => ({
          ...prevData,
          [section]: {
            ...prevData[section],
            [name]: value,
          },
        }));
      }
    } else if (section === "address") {
      // If section is address, update it as an object directly
      setFormData((prevData) => ({
        ...prevData,
        address: {
          ...prevData.address,
          [name]: value,
        },
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [section]: {
          ...prevData[section],
          [name]: value,
        },
      }));
    }
  };

  const [readOnly, setReadOnly] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedCategory]);

  const resetForm = () => {
    setFormData({
      customer: {
        title: "",
        firstName: "",
        lastName: "",
        middleName: "",
        homePhone: "",
        fax: "",
        businessPhone: "",
        customrType: "",
        emailID: "",
      },
      address: [
        {
          street1: "",
          street2: "",
          city: "",
          state: "",
          country: "",
          PostalCode: "",
        },
      ],
      order: {
        shippingAmount: "",
        priceAmount: "",
        specialInstructions: "",
        ordersSubtotal: "",
        shippingMethod: "",
      },
      orderitem: [],
    });
    setSelectedPlan(null);
    setSelectedCategory(null);
    setStep(1);
  };

  return (
    <>
      <div className="anonymous-container">
        {step === 1 && (
          <>
            <div className="plan-main-container">
              <Slider autoplay={true} autoplaySpeed={3000} infinite={true}>
                <div>
                  <img className="img-style" src={Image1} alt="first" />
                </div>
                <div>
                  <img className="img-style" src={Image2} alt="second" />
                </div>
                <div>
                  <img className="img-style" src={Image3} alt="third" />
                </div>
                <div>
                  <img className="img-style" src={Image4} alt="fourth" />
                </div>
                {/* <div>
                  <img className="img-style" src={Image5} alt="fifth" />
                </div> */}
              </Slider>
              {/* <h2 style={{ fontFamily: "serif", textAlign: "center" }}>
                Buy a New Plan
              </h2> */}
              <h2 class="glowing-btn">
                <span class="glowing-txt">
                  Buy a&nbsp;<span class="faulty-letter">New&nbsp;</span>Plan
                </span>
              </h2>
              <div className="category-container">
                {Object.keys(products).map((category, index) => (
                  <div
                    key={index}
                    className={`category-label box ${
                      selectedCategory === category ? "selected-category" : ""
                    }`}
                    onClick={() => handleCategoryChange(category)}
                  >
                    {category}
                  </div>
                ))}
              </div>
              {selectedCategory && (
                <div className="plan-container">
                  {products[selectedCategory].map((plan, index) => (
                    <div ref={scrollRef} key={index} className="plan-item">
                      <div>
                        <strong>Price:</strong> ${plan.price}
                      </div>
                      <div>
                        <strong>Validity:</strong> {plan.validity}
                      </div>
                      <div>
                        <strong>Data:</strong> {plan.data}
                      </div>
                      <div>
                        <strong>Speed:</strong> {plan.speed}
                      </div>
                      <div>
                        <strong>Voice:</strong> {plan.voice}
                      </div>
                      <button
                        className={
                          formData.orderitem.some((item) => item.plan === plan)
                            ? "selected"
                            : "btn-select"
                        }
                        onClick={() => handlePlanSelect(plan)}
                      >
                        {formData.orderitem.some((item) => item.plan === plan)
                          ? "Selected"
                          : "Select"}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {selectedCategory && (
              <div className="button-container" style={{ margin: "0" }}>
                <button
                  className="btn-next-1"
                  onClick={handleNext}
                  // disabled={!selectedCategory}
                  disabled={formData.orderitem.length === 0}
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}

        {step === 2 && selectedPlan && (
          <>
            <div className="customerInfo-container">
              <h3 style={{ fontFamily: "serif", textAlign: "center" }}>
                Customer Information:
              </h3>
              <form className="form-container">
                {/* Customer Information fields */}
                <div className="row">
                  {" "}
                  <div className="form-element title">
                    <label style={{ marginBottom: "8px" }}>Title:</label>
                    <select
                      className="select-dropdown"
                      name="title"
                      value={formData.customer.title}
                      onChange={(e) => handleChange(e, "customer")}
                    >
                      <option value="">Select Title</option>
                      <option key="Mr" value="Mr">
                        Mr
                      </option>
                      <option key="Ms" value="Ms">
                        Ms
                      </option>
                      <option key="Mrs" value="Mrs">
                        Mrs
                      </option>
                    </select>
                  </div>
                  <div className="form-element">
                    <label>First Name:</label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.customer.firstName}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Middle Name:</label>
                    <input
                      type="text"
                      name="middleName"
                      value={formData.customer.middleName}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Last Name:</label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.customer.lastName}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                </div>
                <div className="row">
                  {/* <div className="form-element">
                <label>Suffix:</label>
                <input
                  type="text"
                  name="suffix"
                  value={formData.customer.suffix}
                  onChange={(e) => handleChange(e, "customer")}
                />
              </div> */}
                  <div className="form-element">
                    <label>Email:</label>
                    <input
                      type="email"
                      name="emailID"
                      value={formData.customer.emailID}
                      onChange={(e) => handleChange(e, "customer")}
                      required
                    />
                  </div>
                </div>
                {/* <div className="form-element"></div> */}
                {/* </div> */}
                <div className="row">
                  {" "}
                  <div className="form-element">
                    <label>Home Phone:</label>
                    <input
                      type="text"
                      name="homePhone"
                      value={formData.customer.homePhone}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Fax:</label>
                    <input
                      type="text"
                      name="fax"
                      value={formData.customer.fax}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Business Phone:</label>
                    <input
                      type="text"
                      name="businessPhone"
                      value={formData.customer.businessPhone}
                      onChange={(e) => handleChange(e, "customer")}
                    />
                  </div>
                </div>
                <div className="row">
                  {/* <div className="form-element">
                <label style={{ marginBottom: "8px" }}>Customer Type</label>
                <select
                  className="select-dropdown"
                  name="customrType"
                  value={formData.customer.customrType}
                  onChange={(e) => handleChange(e, "customer")}
                >
                  <option value="">Select Type</option>
                  <option key="Gold" value="Gold">
                    Gold
                  </option>
                  <option key="Silver" value="Silver">
                    Silver
                  </option>
                  <option key="Platinum" value="Platinum">
                    Platinum
                  </option>
                </select>
              </div> */}
                </div>
              </form>
            </div>
            <div className="button-container">
              <button className="btn-back-1" onClick={handleBack}>
                Back
              </button>
              <button className="btn-next-2 custom" onClick={handleNext}>
                Next
              </button>
            </div>
          </>
        )}

        {step === 3 && selectedPlan && (
          <>
            {" "}
            <div className="customerInfo-container">
              <h3 style={{ fontFamily: "serif", textAlign: "center" }}>
                Address Information:
              </h3>
              <form className="form-container">
                {/* Address Information fields */}
                <div className="row">
                  <div className="form-element">
                    <label>Street 1:</label>
                    <input
                      type="text"
                      name="street1"
                      value={formData.address.street1}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Street 2:</label>
                    <input
                      type="text"
                      name="street2"
                      value={formData.address.street2}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                  <div className="form-element">
                    <label>State:</label>
                    <input
                      type="text"
                      name="State"
                      value={formData.address.State}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="form-element">
                    <label>City:</label>
                    <input
                      type="text"
                      name="city"
                      value={formData.address.city}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Country:</label>
                    <input
                      type="text"
                      name="country"
                      value={formData.address.country}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Postal Code:</label>
                    <input
                      type="text"
                      name="PostalCode"
                      value={formData.address.PostalCode}
                      onChange={(e) => handleChange(e, "address")}
                    />
                  </div>
                  {/* <div className="form-element">
                <label>Address Type</label>
                <input
                  type="text"
                  name="addressType"
                  value={formData.address.addressType}
                  onChange={(e) => handleChange(e, "address")}
                />
              </div> */}
                </div>
              </form>
            </div>
            <div className="button-container">
              <button className="btn-back-2" onClick={handleBack}>
                Back
              </button>
              <button className="btn-next-3 custom" onClick={handleNext}>
                Next
              </button>
            </div>
          </>
        )}

        {step === 4 && selectedPlan && (
          <>
            <div className="customerInfo-container">
              <h3 style={{ fontFamily: "serif", textAlign: "center" }}>
                Order Information:
              </h3>
              <form className="form-container">
                <div className="row">
                  <div className="form-element">
                    <label>Shipping Amount:</label>
                    <input
                      type="text"
                      name="shippingAmount"
                      value={readOnly ? "99" : formData.order.shippingAmount}
                      readOnly={readOnly}
                      onChange={(e) => handleChange(e, "order")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Price Amount:</label>
                    <input
                      type="text"
                      name="priceAmount"
                      value={
                        readOnly
                          ? selectedPlan.price
                          : formData.order.priceAmount
                      }
                      readOnly={readOnly}
                      onChange={(e) => handleChange(e, "order")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Order SubTotal:</label>
                    <input
                      type="text"
                      name="ordersSubtotal"
                      value={
                        readOnly
                          ? selectedPlan.price
                          : formData.order.ordersSubtotal
                      }
                      readOnly={readOnly}
                      onChange={(e) => handleChange(e, "order")}
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="form-element">
                    <label>Special Instructions:</label>
                    <input
                      type="text"
                      name="specialInstructions"
                      value={formData.order.specialInstructions}
                      onChange={(e) => handleChange(e, "order")}
                    />
                  </div>
                  <div className="form-element">
                    <label>Service Type:</label>
                    <input
                      type="text"
                      name="serviceType"
                      value={selectedCategory}
                      readOnly={true}
                    />
                  </div>
                  {/* <div className="form-element">
                    <label>Shipping Method:</label>
                    <input
                      type="text"
                      name="shippingMethod"
                      value={formData.order.shippingMethod}
                      onChange={(e) => handleChange(e, "order")}
                    />
                  </div> */}
                </div>
              </form>
            </div>
            <div className="button-container">
              <button className="btn-back-3 back-custom" onClick={handleBack}>
                Back
              </button>
              <button
                className="btn-submit-1"
                type="button"
                onClick={handleSubmit}
              >
                Submit
              </button>
            </div>{" "}
            {/* <Modal isOpen={isModalOpen} onClose={closeModal} /> */}
          </>
        )}
      </div>
    </>
  );
};

export default OrderForm;
