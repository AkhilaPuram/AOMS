// CustomerHome.js
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
//import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import "./CustomerHome.css"; // Import your CSS file
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faChevronRight } from "@fortawesome/free-solid-svg-icons";
import Profile from "../../tabs/Profile/Profile";
import PlanDetails from "./PlanDetails";
import axios from "axios";

function CustomerHome(props) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();
  const [isPlan, setIsPlan] = useState(false);
  const [plan, setPlan] = useState("");
  const [next, setNext] = useState(false);
  const [planDetails, setPlanDetails] = useState("");
  const [List, setList] = useState([]);
  const [isSelect, setSelect] = useState(true);
  //const[count,setCount]=useState(0);
  // const[list,newList]=useState(Details);
  //console.log(list);
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };
  const [orderDetails, setOrderDetails] = useState();
  const baseURL = "http://10.13.8.223:8899/api/getproducts";
  const [email, setEmail] = useState("");
  const [groups, setGroups] = useState([]);

  useEffect(() => {
    const userEmail = localStorage.getItem("email");
    const userGroups = localStorage.getItem("groups");

    if (userEmail && userGroups) {
      setEmail(userEmail);
      setGroups(userGroups);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (plan) {
      setList([...PlanDetails[plan]]);
    }
  }, [plan]);
  const fetchData = async () => {
    try {
      let services = await axios.get(baseURL).then((res) => res.data);

      setPlanDetails(services);
    } catch (err) {
      console.log(err.message);
    }
  };

  const updateCount = (id) => {
    const newList = List.map((item, i) => {
      if (i === id) {
        const updatedItem = {
          ...item,
          count: item.count + 1,
        };
        return updatedItem;
      }

      return item;
    });

    setList(newList);
  };

  const dereaseCount = (id) => {
    const newList = List.map((item, i) => {
      if (i === id) {
        const updatedItem = {
          ...item,
          count: item.count - 1,
        };
        return updatedItem.count >= 0 ? updatedItem : item;
      }

      return item;
    });

    setList(newList);
  };

  const handlePayment = () => {
    // Open payment page in a new tab
    window.open("/payment", "_blank");
  };

  const handleLogout = () => {
    // Perform logout actions if needed
    // For example, clearing session, etc.
    // Then redirect to the login page
    navigate("/"); // Redirect to the login page
  };

  const handleMyProfile = () => {
    // Redirect to the profile page
    navigate("/profile");
  };

  const handleHome = () => {
    navigate("/customer-home");
  };

  let apipost = {
    customer: {
      title: "Mrs",
      firstName: "rakesh",
      lastName: "kumar",
      middleName: "rakoi",
      homePhone: "9676476493",
      fax: "12560777",
      businessPhone: "9000008787",
    },
    address: [
      {
        street1: 456,
        street2: 2,
        city: "test 1",
        State: "AP",
        country: "India",
        PostalCode: "test1",
        addressType: "Home",
      },
      {
        street1: 5678,
        street2: "fjlksjf",
        city: "test 21",
        State: "TS",
        country: "India",
        postalCode: "dfjlksjf1",
        addressType: "Mailing",
      },
    ],
    order: {
      shippingAmount: 12.67,
      priceAmount: "837932",
      specialInstructions: "order at door step",
    },
    orderitem: [
      {
        productID: "1",
        taxAmount: 789,
        quantity: 5,
        description: "5g",
      },
      {
        productID: "2",
        taxAmount: 200,
        quantity: 2,
        description: "Modem",
      },
    ],
  };
  // to pass the order details to api;

  const passOnDetails = (ele) => {
    props.OrderDetails(ele);
    setNext(true);
  };
  const handleNext = () => {
    navigate("../OrderDetails");
  };

  const handleInput = (e) => {
    setPlan(e.target.value);

    setIsPlan(true);
  };
  return (
    <div className="customer-home-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <a href="/customer-home">Home</a>
            </li>
            <li>
              <a href="/orders">Orders</a>
            </li>
            {/* <li>
              <a href="/bills">Bills</a>
            </li> */}
          </ul>
        </nav>
      </aside>
      <main className="main-content">
        <header>
          <div
            className="profile-icon profile-icon-container"
            onClick={toggleDropdown}
          >
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
              <div className="dropdown">
                <ul>
                  <li>
                    <a href="#" onClick={handleMyProfile}>
                      My Profile
                    </a>
                  </li>
                  <li>
                    <a href="#" onClick={props.handleLogout}>
                      Logout
                    </a>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </header>
        <section className="content">
          <div class="container">
            <div class="card">
              <h2>Prepaid</h2>
              <p>9876543210</p>
            </div>
            <div class="card">
              <h2>My Data</h2>
              <p>3.25 GB</p>
            </div>
            <div class="card">
              <h2>My Pack</h2>
              <p>Rs 155 Unlimited</p>
            </div>
            <div className="card">
              <p>Email: {email}</p>
              <p>Groups: {groups}</p>
            </div>
          </div>
          <div class="vcard">
            <h2>Recharge</h2>
            <h3>Select a Service</h3>
            <div class="radio-group">
              <label className="label-plan">
                <input
                  className="input-plan"
                  type="radio"
                  name="service"
                  value="Prepaid"
                  onChange={(e) => handleInput(e)}
                />
                Prepaid
              </label>
              <label className="label-plan">
                <input
                  className="input-plan"
                  type="radio"
                  name="service"
                  value="Postpaid"
                  onChange={(e) => handleInput(e)}
                />
                Postpaid
              </label>
              <label className="label-plan">
                <input
                  className="input-plan"
                  type="radio"
                  name="service"
                  value="Fiber"
                  onChange={(e) => handleInput(e)}
                />
                Fiber
              </label>
              <label className="label-plan">
                <input
                  className="input-plan"
                  type="radio"
                  name="service"
                  value="dth"
                  onChange={(e) => handleInput(e)}
                />
                DTH
              </label>
            </div>
            <div class="search-box">
              <input type="text" placeholder="Search for plan" />
            </div>
            <div class="plan-list">
              {isPlan
                ? List.map((ele, i) => (
                    <div class="plan-card" key={i}>
                      <div class="plan-details">
                        <div>
                          {" "}
                          <p>Price: {ele.price}</p>
                        </div>
                        <div>
                          <p>Data: {ele.data}</p>
                        </div>
                        <div>Quantity:{ele.count}</div>
                        <div>
                          <p>Validity: {ele.validity}</p>
                        </div>
                      </div>
                      <div>
                        <button
                          style={{ margin: "1px", width: "5px" }}
                          onClick={() => updateCount(i)}
                        >
                          +
                        </button>

                        <button
                          style={{ margin: "1px", width: "5px" }}
                          onClick={() => dereaseCount(i)}
                        >
                          -
                        </button>
                      </div>
                      <div>
                        <button
                          onClick={() => {
                            setNext(true);
                            passOnDetails(ele);
                            setSelect(false);
                          }}
                        >
                          {isSelect ? "Select" : "Selected"}
                        </button>
                      </div>
                    </div>
                  ))
                : "Select one Option"}
              {next && (
                <button style={{ width: "100px" }} onClick={handleNext}>
                  Next
                </button>
              )}
              {/* <div class="plan-card">
                <div class="plan-details">
                   <div> <p>Amount: $10</p></div>
                    <div><p>Data: 2GB</p></div>
                    <div><p>Validity: 30 days</p></div>
                </div>
                <div class="chevron-icon">
                <FontAwesomeIcon icon={faChevronRight} onClick={handlePayment}/>
                </div>
            </div>
            <div class="plan-card">
                <div class="plan-details">
                   <div> <p>Amount: $10</p></div>
                    <div><p>Data: 2GB</p></div>
                    <div><p>Validity: 30 days</p></div>
                </div>
                <div class="chevron-icon">
                <FontAwesomeIcon icon={faChevronRight} onClick={handlePayment}/>
                </div>
            </div>
            <div class="plan-card">
                <div class="plan-details">
                   <div> <p>Amount: $10</p></div>
                    <div><p>Data: 2GB</p></div>
                    <div><p>Validity: 30 days</p></div>
                </div>
                <div class="chevron-icon" onClick={handlePayment}>
                <FontAwesomeIcon icon={faChevronRight} />
                </div>
            </div> */}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default CustomerHome;
