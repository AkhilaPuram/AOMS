const PlanDetails ={
    "Prepaid": [
        {
            "voice": "FREE",
            "validity": "30 days",
            "data": "UNLIMITED",
            "price": "599",
            "speed": "100 Mbps (100 Mbps Upload & 100 Mbps Download)",
            "count":0
        },
        {
            "voice": "FREE",
            "validity": "30 days",
            "data": "Unlimited",
            "price": "1499",
            "speed": "300 Mbps (300 Mbps Upload and 300 Mbps Download)",
            "count":0
        },
        {
            "voice": "\nFree",
            "validity": "360 days + 30 days",
            "data": "\nUnlimited",
            "price": "4788",
            "speed": "30 Mbps (30 Mbps Upload & 30 Mbps Download)",
            "count":0
        }
    ],
    "Fiber": [
        {
            "voice": "NULL",
            "validity": "one year",
            "data": "UNLIMITED",
            "price": "5988",
            "speed": "Up to 40Mbps",
            "count":0
            
        },
        {
            "voice": "NULL",
            "validity": "One Year",
            "data": "UNLIMITED",
            "price": "6499",
            "speed": "Up to 45Mbps",
            "count":0
           
        }
    ],
    "Postpaid": [
        {
            "voice": "FREE",
            "validity": "\nBill Cycle",
            "data": "Unlimited",
            "price": "999",
            "speed": "150 Mbps (150 Mbps Upload and 150 Mbps Download)",
            "count":0
        },
        {
            "voice": "FREE",
            "validity": "Bill Cycle",
            "data": "UNLIMITED",
            "price": "899",
            "speed": "100 Mbps (100 Mbps Upload and 100 Mbps Download)",
            "count":0
        },
        {
            "voice": "FREE",
            "validity": "Bill Cycle",
            "data": "UNLIMITED",
            "price": "4788",
            "speed": "30 Mbps (30 Mbps Upload and 30 Mbps Download)",
            "count":0
        }
    ]
}

export default PlanDetails;