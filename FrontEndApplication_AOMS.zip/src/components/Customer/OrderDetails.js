// Bills.js
import React, { useState,useEffect} from 'react';
import { useNavigate } from 'react-router-dom';
import './orderDetails.css'; // Import CSS for Bills component
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import axios from "axios";
function OrderDetails(props) {
   console.log(props);
   const propsData=[...props.orderCard]
   console.log(propsData)
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate();
 
    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };
 
    const handleLogout = () => {
        // Perform logout actions if needed
        // For example, clearing session, etc.
        // Then redirect to the login page
        navigate('/'); // Redirect to the login page
    };
 
    const handleMyProfile = () => {
        // Redirect to the profile page
        navigate('/profile');
    };
     // Mock data for orders
     const [orders, setOrders] = useState(propsData);
 
     useEffect(() => {
        setOrders(propsData);
       
      }, []);
     
    const priceAmount =propsData.reduce((acc,ele)=>acc+Number(ele.price),0);
   
    const orderItems =propsData.map(function(ele,index){return {"productID":index+1,"taxAmount":(ele.price*ele.count/100)*2,"quantity":ele.count,"descritpion":"5g"}})
    // Function to handle expanding/collapsing order details
 
    const toggleOrderDetails = (index) => {
        const updatedOrders = [...orders];
        updatedOrders[index].expanded = !updatedOrders[index].expanded;
        setOrders(updatedOrders);
    };
    const postData={
        "customer" : {
         
       
          "title":"Mrs",
          "firstName":"rakesh",
          "lastName":"kumar",
          "middleName":"rakoi",  
          "homePhone":"9676476493",  
          "fax":"12560777",
          "businessPhone":"9000008787"
         
        },
      "address": [  
          {
            "street1":456,
            "street2":2,
            "city":"test 1",
            "State":"AP",
            "country":"India",
            "PostalCode":"test1",
            "addressType":"Home"
          },
          {
            "street1":5678,
            "street2":"fjlksjf",
            "city":"test 21",
            "State":"TS",
            "country":"India",
            "postalCode":"dfjlksjf1",
            "addressType":"Mailing"
          }
        ],
        "order" : {
          "shippingAmount":12.67,
          "priceAmount":String(priceAmount),
          "specialInstructions":"order at door step"
        },
        "orderitem": orderItems
      }
    //Fnction to post data to API and move to payment
    const handleMoveNext=async()=>{
 
        try{ let result=await axios.post("",postData).then((res)=>res.data)
 
        }catch(err){console.log(err)}
        navigate("../Payment")
    }
 
    return ( <div className="customer-home-container">
    <aside className="sidebar">
    <nav>
                    <ul>
                    <li><a href="/customer-home">Home</a></li>
                <li><a href="/orders">Orders</a></li>
                <li><a href="/bills">Bills</a></li>
                    </ul>
                </nav>
    </aside>
    <main className="main-content">
        <header>
        <div className="profile-icon profile-icon-container" onClick={toggleDropdown}>
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
                    <div className="dropdown">
                        <ul>
                            <li><a href="#" onClick={handleMyProfile}>My Profile</a></li>
                            <li><a href="#" onClick={handleLogout}>Logout</a></li>
                        </ul>
                    </div>
                )}
             </div>
        </header>
       
        <div className="Info-container">
       
        <section className="content">
        <div className="orders-user-info"><h3>UserInfo</h3>
        <div className="orders-user-info-items"><strong>Title:</strong> <span>Mr</span></div>
        <div className="orders-user-info-items"><strong>First Name:</strong> <span>Rakesh</span></div>
        <div className="orders-user-info-items"><strong>Last Name:</strong> <span>Varma</span></div>
        <div className="orders-user-info-items"><strong>Middle Name:</strong> <span>Kumar</span></div>
        <div className="orders-user-info-items"><strong>Home Phone:</strong> <span>7759403998</span></div>
        <div className="orders-user-info-items"><strong>Fax:</strong> <span>1234567</span></div>
        <div className="orders-user-info-items"><strong>BusinessPhone:</strong><span>8978584856</span></div>
   
        </div>
        </section>
        <section className="content">
        <div className="orders-user-info">
        <h3>Home Address</h3>
        <div className="orders-user-info-items"><strong>Street1:</strong><span>123</span></div>
        <div className="orders-user-info-items"><strong>Street2:</strong><span>456</span></div>
        <div className="orders-user-info-items"><strong>city:</strong><span>Hyderabad</span></div>
        <div className="orders-user-info-items"><strong>State:</strong><span>Telengana</span></div>
        <div className="orders-user-info-items"><strong>country:</strong><span>India</span></div>
        <div className="orders-user-info-items"><strong>PostalCode:</strong><span>50008134</span></div>
        <div className="orders-user-info-items"><strong>addressType:</strong><span>Home</span></div>
   
        </div>
        </section>
        </div>
        <section className="content">
        <div className="orders-container">
            <h2>All Orders</h2>
            {orders.map((order, index) => (
                <div key={index} className="order-card">
                    <div className="order-summary" onClick={() => toggleOrderDetails(index)}>
                        <div className='dropdown-order'>
                            <p>Order ID: {index}</p>
                            <p>Data: {order.data}</p>
                            <p>Price:{order.price}</p>
                            <p>Validity: {order.validity}</p>
                            <p>Quantity:{order.count}</p>
                        </div>
                       
                    </div>
                 
                </div>
            ))}
             {orders&&<button style={{width:"100px"}} onClick={handleMoveNext}>Next</button>}
        </div>
        </section>
    </main>
</div>
       
    );
}
 
export default OrderDetails;