// src/Login.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css'; // Import the CSS file
 
function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('customer'); // Default role
 
    const navigate = useNavigate();
 
    const handleLogin = (e) => {
        e.preventDefault();
        // Your authentication logic goes here
        // For simplicity, let's assume authentication is successful
 
        // Navigate based on role
        if (role === 'customer') {
            navigate('/customer-home');
        } else if (role === 'admin') {
            navigate('/admin-home');
        }else if (role === 'inventoryManager') {
            navigate('/inventoryManager-orders');
        }else if (role === 'serviceManager') {
            navigate('/serviceManager-orders');
        }else if (role === 'serviceEngineer') {
            navigate('/serviceEngineer-orders');
        }
       
    };
 
    return (
        <div className="login-container">
           {/* <a href="http://localhost:3001/" target="_self"><h2>Login</h2></a>/ <a href="#" onClick={alert("Signup")}><h2>Signup</h2></a> */}
            <form className="login-form" onSubmit={handleLogin}>
                <div className="form-group">
                    <label>Username</label>
                    <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Role</label>
                    <select value={role} onChange={(e) => setRole(e.target.value)}>
                        <option value="customer">Customer</option>
                        <option value="admin">Admin</option>
                        <option value="inventoryManager">Inventory Manager</option>
                        <option value="serviceManager">service Manager</option>
                        <option value="serviceEngineer">service Engineer</option>
                       
                    </select>
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    );
}
 
export default Login;
 
